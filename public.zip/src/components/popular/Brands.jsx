import { Container } from "@mui/system";
import React from "react";
import Title from "../title/Title";
import "../../assets/scss/_brands.scss";
import { Link } from "react-router-dom";
import Slider from "react-slick";
import { BsArrowLeft, BsArrowRight } from "react-icons/bs";

const Brands = () => {
  return (
    <Container maxWidth="xl">
      <Title title={"Популярные бренды"} style="f-bold" />
      <div className="brands my-4">
        <Link to="/" className="brand">
          <img src="https://picsum.photos/160/88" alt="" />
        </Link>
        <Link to="/" className="brand">
          <img src="https://picsum.photos/160/88" alt="" />
        </Link>
        <Link to="/" className="brand">
          <img src="https://picsum.photos/160/88" alt="" />
        </Link>
        <Link to="/" className="brand">
          <img src="https://picsum.photos/160/88" alt="" />
        </Link>
        <Link to="/" className="brand">
          <img src="https://picsum.photos/160/88" alt="" />
        </Link>
        <Link to="/" className="brand">
          <img src="https://picsum.photos/160/88" alt="" />
        </Link>
        <Link to="/" className="brand">
          <img src="https://picsum.photos/160/88" alt="" />
        </Link>
        <Link to="/" className="brand">
          <img src="https://picsum.photos/160/88" alt="" />
        </Link>
        <Link to="/" className="brand">
          <img src="https://picsum.photos/160/88" alt="" />
        </Link>
        <Link to="/" className="brand">
          <img src="https://picsum.photos/160/88" alt="" />
        </Link>
        <Link to="/" className="brand">
          <img src="https://picsum.photos/160/88" alt="" />
        </Link>
      </div>
    </Container>
  );
};

export default Brands;
