import React from "react";
import "../../assets/scss/_cart.scss";
import { BiHeart } from "react-icons/bi";
import { HiOutlineShoppingCart } from "react-icons/hi";
import { useNavigate } from "react-router-dom";

const Cart = ({ cart, favorite }) => {
  const navigate = useNavigate();

  return (
    <div className="cart">
      <button
        className={`${!favorite ? "favorite" : "favorited"} favorite-icon`}
      >
        <BiHeart size={24} />
      </button>
      <div className="flex flex-col">
        <div onClick={() => navigate("/detail")} className="cart-image">
          <img src="https://picsum.photos/208/165" alt="" />
        </div>
        <div onClick={() => navigate("/detail")} className="cart-name">
          Acer Aspire 3 Intel Pentium N4500/4GB/1TB HDD/Intel Cor i 10
        </div>
        <div className="rassrochka f-bold text-center">389 200 сум/ 12 мес</div>
        <div className="cart-action">
          <div className="cart-price f-bold">3 113 600 Сум</div>
          <button className="cart-basket hover:shadow-lg shadow-none">
            <HiOutlineShoppingCart stroke="rgb(33, 26, 26)" size={24} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Cart;
