import React from "react";
import Slider from "react-slick";
import "../../assets/scss/_slider.scss";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { Link } from "react-router-dom";
import { FiArrowLeftCircle, FiArrowRightCircle } from "react-icons/fi";

const HomeSlider = () => {
  return (
    <Slider
      className="slider"
      infinite={true}
      speed={2000}
      autoplay={true}
      autoplaySpeed={5000}
      slidesToShow={1}
      slidesToScroll={1}
      nextArrow={<FiArrowRightCircle size={16} stroke="#000" fill="#fff" />}
      prevArrow={<FiArrowLeftCircle size={16} stroke="#000" fill="#fff" />}
    >
      <Link to="/special-order">
        <img src="https://picsum.photos/1400/310" alt="" />
      </Link>
      <Link to="/special-order">
        <img src="https://picsum.photos/1400/310" alt="" />
      </Link>
      <Link to="/special-order">
        <img src="https://picsum.photos/1400/310" alt="" />
      </Link>
    </Slider>
  );
};

export default HomeSlider;
